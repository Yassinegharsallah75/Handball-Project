
import React from 'react';
import { View, StyleSheet } from 'react-native';

/**
 * boxes: [{cls, conf, xmin, ymin, xmax, ymax}]
 * containerSize: {width, height}
 */
export default function OverlayBoxes({ boxes = [], containerSize }) {
  return (
    <View pointerEvents="none" style={[styles.overlay, { width: containerSize.width, height: containerSize.height }]}>
      {boxes.map((b, i) => {
        const left = b.xmin;
        const top = b.ymin;
        const width = b.xmax - b.xmin;
        const height = b.ymax - b.ymin;
        return (
          <View key={i} style={[styles.box, { left, top, width, height }]} />
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  overlay: {
    position: 'absolute',
    top: 0, left: 0,
  },
  box: {
    position: 'absolute',
    borderWidth: 2,
    borderColor: '#00FF00',
    borderRadius: 6,
  }
});
