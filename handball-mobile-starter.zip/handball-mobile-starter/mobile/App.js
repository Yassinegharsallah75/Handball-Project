
import React, { useEffect, useRef, useState } from 'react';
import { StyleSheet, Text, View, TouchableOpacity, ActivityIndicator, Dimensions } from 'react-native';
import { Camera } from 'expo-camera';
import { StatusBar } from 'expo-status-bar';
import { detectFrame, BACKEND_URL } from './api';
import OverlayBoxes from './components/OverlayBoxes';

export default function App() {
  const [hasPermission, setHasPermission] = useState(null);
  const [busy, setBusy] = useState(false);
  const [detections, setDetections] = useState([]);
  const cameraRef = useRef(null);
  const window = Dimensions.get('window');

  useEffect(() => {
    (async () => {
      const { status } = await Camera.requestCameraPermissionsAsync();
      setHasPermission(status === 'granted');
    })();
  }, []);

  const snap = async () => {
    if (!cameraRef.current || busy) return;
    setBusy(true);
    try {
      const photo = await cameraRef.current.takePictureAsync({ skipProcessing: true });
      const res = await detectFrame(photo.uri);
      setDetections(res?.detections ?? []);
    } catch (e) {
      console.warn('detect error', e.message);
    } finally {
      setBusy(false);
    }
  };

  if (hasPermission === null) return <View style={styles.center}><Text>Requesting camera permission…</Text></View>;
  if (hasPermission === false) return <View style={styles.center}><Text>No access to camera</Text></View>;

  return (
    <View style={styles.container}>
      <Camera style={styles.camera} ref={cameraRef} ratio="16:9" />
      <OverlayBoxes boxes={detections} containerSize={{ width: window.width, height: window.width * 16/9 }} />
      <View style={styles.bottomBar}>
        <Text style={styles.url}>Backend: {BACKEND_URL}</Text>
        <TouchableOpacity onPress={snap} style={styles.button} disabled={busy}>
          {busy ? <ActivityIndicator /> : <Text style={styles.buttonText}>SNAP & DETECT</Text>}
        </TouchableOpacity>
      </View>
      <StatusBar style="auto" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000' },
  camera: { width: '100%', aspectRatio: 16/9 },
  bottomBar: { padding: 12, backgroundColor: '#111' },
  button: { backgroundColor: '#0A84FF', padding: 14, borderRadius: 10, alignItems: 'center', marginTop: 8 },
  buttonText: { color: 'white', fontWeight: 'bold' },
  url: { color: '#9aa0a6' },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' }
});
