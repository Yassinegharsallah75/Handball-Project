
# Mobile App (React Native + Expo)

A simple camera app that captures a frame, sends it to the backend `/detect` endpoint, and overlays bounding boxes.

## Quick start

1. Install Node.js (LTS) and Yarn or npm.
2. Install Expo CLI:
   ```bash
   npm i -g expo
   ```
3. Install dependencies:
   ```bash
   npm install
   # or: yarn
   ```
4. Start the dev server:
   ```bash
   npx expo start
   ```
5. In `api.js`, set your backend URL, e.g. `http://192.168.1.20:8000`.

## Build APK (Expo)
- EAS Build is recommended: https://docs.expo.dev/build/introduction/
- Or eject to bare React Native if you need custom native modules.

## Notes
- The overlay expects detection items shaped like:
  ```json
  { "cls": "ball", "conf": 0.89, "xmin": 100, "ymin": 120, "xmax": 180, "ymax": 200 }
  ```
