
import * as FileSystem from 'expo-file-system';

// !!! Change this to your LAN IP of the backend machine
// e.g. http://192.168.1.20:8000
export const BACKEND_URL = 'http://127.0.0.1:8000';

export async function detectFrame(uri) {
  const formData = new FormData();
  formData.append('file', {
    uri,
    name: 'frame.jpg',
    type: 'image/jpeg',
  });

  const res = await fetch(`${BACKEND_URL}/detect`, {
    method: 'POST',
    body: formData,
    headers: { 'Accept': 'application/json' }
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return await res.json();
}
