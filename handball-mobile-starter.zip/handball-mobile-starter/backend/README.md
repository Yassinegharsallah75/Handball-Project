
# Backend (FastAPI + YOLO/OpenCV)

This FastAPI server wraps your Python detection/velocity logic so a mobile app can call it.

## Quick start (local)

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
cp .env.example .env  # and edit API_HOST if needed
python server.py
```

The API will start at `http://0.0.0.0:8000`.
Find your machine IP (e.g., `192.168.1.20`) and use `http://192.168.1.20:8000` in the mobile app.

## Endpoints

- `POST /detect` — send a single frame (JPEG/PNG). Returns detections.
- `POST /velocity` — send 2 frames and time delta (or frame indices). Returns estimated ball speed.
- `GET /health` — health check.

## Notes

- Replace the TODOs in `model.py` with your actual YOLO + velocity logic.
- Keep inputs/outputs JSON-friendly. The mobile app draws bounding boxes from the returned list.
