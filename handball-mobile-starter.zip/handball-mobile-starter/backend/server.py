
import io, os
from typing import List, Optional, Dict, Any
from fastapi import FastAPI, File, UploadFile, Form
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import numpy as np
import cv2

from model import load_model, detect_objects, estimate_velocity

API_HOST = os.getenv("API_HOST", "0.0.0.0")
API_PORT = int(os.getenv("API_PORT", "8000"))
MODEL_PATH = os.getenv("MODEL_PATH", "best.pt")

app = FastAPI(title="Handball AI Backend", version="1.0.0")

# Allow all origins for dev; lock down in production
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

MODEL = load_model(MODEL_PATH)

class Detection(BaseModel):
    cls: str
    conf: float
    xmin: int
    ymin: int
    xmax: int
    ymax: int

class DetectResponse(BaseModel):
    detections: List[Detection]

class VelocityRequest(BaseModel):
    # Base64 or multi-part is possible; we support multi-part here
    pass

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/detect", response_model=DetectResponse)
async def detect(file: UploadFile = File(...)):
    # Read image bytes
    data = await file.read()
    nparr = np.frombuffer(data, np.uint8)
    img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
    detections = detect_objects(MODEL, img)
    return {"detections": detections}

@app.post("/velocity")
async def velocity(
    file1: UploadFile = File(..., description="Earlier frame"),
    file2: UploadFile = File(..., description="Later frame"),
    time_delta_ms: float = Form(..., description="Delta between frames in milliseconds"),
    px_per_meter: float = Form(..., description="Calibration factor: pixels per meter"),
):
    # Read both frames
    data1 = await file1.read()
    data2 = await file2.read()
    img1 = cv2.imdecode(np.frombuffer(data1, np.uint8), cv2.IMREAD_COLOR)
    img2 = cv2.imdecode(np.frombuffer(data2, np.uint8), cv2.IMREAD_COLOR)

    result = estimate_velocity(MODEL, img1, img2, time_delta_ms, px_per_meter)
    return result

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host=API_HOST, port=API_PORT)
