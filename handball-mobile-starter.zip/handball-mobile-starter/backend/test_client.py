
# Quick test client for /detect
import requests, sys

URL = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:8000/detect"
IMG = sys.argv[2] if len(sys.argv) > 2 else "test.jpg"

with open(IMG, "rb") as f:
    files = {"file": ("frame.jpg", f, "image/jpeg")}
    r = requests.post(URL, files=files, timeout=30)
    print(r.status_code, r.text)
