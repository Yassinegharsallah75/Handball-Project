
# Handball Mobile Starter — Option A (Hybrid)

This zip contains:
- **backend/** FastAPI server that wraps your Python model logic.
- **mobile/** React Native (Expo) app that captures a frame, sends it to the backend, and draws boxes.

## How to run (TL;DR)

### 1) Backend
```
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python server.py
```
Find your machine's LAN IP (e.g., `192.168.1.20`).

### 2) Mobile
```
cd mobile
npm install
# or: yarn
# Edit api.js -> set BACKEND_URL to http://<LAN-IP>:8000
npx expo start
```
Open the Expo app on your phone, scan the QR, then tap **SNAP & DETECT**.

## Plug your real logic
- Edit `backend/model.py`: implement `load_model`, `detect_objects`, and `estimate_velocity` using your existing YOLO/OpenCV code.
- Make sure `detect_objects` returns an array of `{cls, conf, xmin, ymin, xmax, ymax}`.

## Production notes
- Add authentication or rate-limiting if exposing the backend publicly.
- Consider deploying backend to a GPU-enabled VM if you need real-time inference.
- Lock CORS origins in `server.py` before shipping.
